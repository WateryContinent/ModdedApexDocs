


RePak.exe "PATHTOYOUROUTPUTJSON\output.json"

timeout /t 3 /nobreak

DEL "C:\Users\PC\AppData\Local\Programs\R5VLibrary\BUILDFOLDERNAME\mods\NAMEOFYOURMOD\paks\Win64\NAMEOFYOURRPAK.rpak"

DEL "C:\Users\PC\AppData\Local\Programs\R5VLibrary\BUILDFOLDERNAME\mods\NAMEOFYOURMOD\paks\Win64\NAMEOFYOURRPAK.starpak"

DEL "C:\Users\PC\AppData\Local\Programs\R5VLibrary\BUILDFOLDERNAME\mods\NAMEOFYOURMOD\paks\Win64\NAMEOFYOURRPAK.opt.starpak"

timeout /t 2 /nobreak

MOVE "RPAKBUILDPATH\build\NAMEOFYOURRPAK.rpak" "C:\Users\PC\AppData\Local\Programs\R5VLibrary\BUILDFOLDERNAME\mods\NAMEOFYOURMOD\paks\Win64"

MOVE "RPAKBUILDPATH\build\NAMEOFYOURRPAK.starpak" "C:\Users\PC\AppData\Local\Programs\R5VLibrary\BUILDFOLDERNAME\mods\NAMEOFYOURMOD\paks\Win64"

MOVE "RPAKBUILDPATH\build\NAMEOFYOURRPAK.opt.starpak" "C:\Users\PC\AppData\Local\Programs\R5VLibrary\BUILDFOLDERNAME\mods\NAMEOFYOURMOD\paks\Win64"

DEL "RPAKBUILDPATH\build\NAMEOFYOURRPAK.starmap"

timeout /t 1 /nobreak

